create view [veilingisgesloten] as
select titel from voorwerp where veilinggesloten = 'wel'
go

