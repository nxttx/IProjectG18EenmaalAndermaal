



-- Beperking B3


CREATE TRIGGER trg_verkoper_validate_bank_credit 
ON verkoper 
FOR INSERT, UPDATE
AS
	DECLARE @v_Gebruiker char(25);
	DECLARE @v_Bank char(20);
	DECLARE @v_Bankrekening char(18);
	DECLARE @v_ControleOptie char(10);
	DECLARE @v_Creditcard numeric(16);
	select @v_Gebruiker=i.Gebruiker,@v_Bank=i.Bank,	@v_Bankrekening=i.Bankrekening,	
	@v_ControleOptie=i.ControleOptie,@v_Creditcard=i.Creditcard 	from Inserted i;

	IF(@v_Bankrekening IS NULL AND @v_Creditcard IS NULL)
		BEGIN
			RAISERROR ('Bank en creditcard kunnen niet beiden leeg zijn', 16, 1)
			ROLLBACK TRANSACTION
		END
	ELSE
		PRINT 'Row Inserted';
go

