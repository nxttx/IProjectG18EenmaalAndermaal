
CREATE TRIGGER ch_Gebruiker_Is_Verkoper
ON Verkoper 
FOR INSERT, UPDATE
AS
	DECLARE @v_Gebruiker char(25);
	DECLARE @v_Gebruiker_Wel char(25);
	select @v_Gebruiker = Gebruiker  	from Inserted i;
	select @v_Gebruiker_Wel= verkoper  	from Gebruiker where gebruikersnaam = @v_Gebruiker;

	IF(@v_Gebruiker_Wel != 'wel')
		BEGIN
			RAISERROR ('Error', 16, 1)
			ROLLBACK TRANSACTION
		END
	ELSE
		PRINT 'Row Inserted';

go

