CREATE VIEW MAx_Category AS SELECT voorwerpinrubriek.RubriekOpLaagsteNiveau, rubriek.rubrieknaam, count(*) maximum FROM "voorwerpinrubriek"
INNER JOIN "rubriek" ON "rubriek"."rubrieknummer" = "voorwerpinrubriek"."RubriekOpLaagsteNiveau"
GROUP BY voorwerpinrubriek.RubriekOpLaagsteNiveau, rubriek.rubrieknaam
go

