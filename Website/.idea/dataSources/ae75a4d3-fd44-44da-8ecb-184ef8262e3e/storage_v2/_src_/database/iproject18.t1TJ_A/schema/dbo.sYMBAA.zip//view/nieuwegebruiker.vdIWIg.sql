create view [nieuwegebruiker] as
select * from gebruiker where is_geverifieerd = 0
go

