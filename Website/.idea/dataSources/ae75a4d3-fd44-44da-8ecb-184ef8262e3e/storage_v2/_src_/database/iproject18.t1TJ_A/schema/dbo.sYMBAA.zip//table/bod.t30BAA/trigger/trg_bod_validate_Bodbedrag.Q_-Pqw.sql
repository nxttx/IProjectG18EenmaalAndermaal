
-- Beperking B5

CREATE TRIGGER [dbo].[trg_bod_validate_Bodbedrag]
ON [dbo].[bod]
instead of INSERT, UPDATE
AS
DECLARE @v_Voorwerp numeric(25);
DECLARE @v_Bodbedrag int;
DECLARE @v_Max_Bodbedrag int;

--save tran poin


SELECT @v_Voorwerp=i.voorwerp, @v_Bodbedrag=cast( i.bodbedrag as int ) from Inserted i;
print 'insert max = ' +  cast(@v_Bodbedrag as char);

SELECT @v_Max_Bodbedrag = max(CAST(bodbedrag AS INT)) FROM  [dbo].[bod] WHERE voorwerp = @v_Voorwerp;
print 'table max = ' + cast( @v_Max_Bodbedrag as char);


IF   @v_Bodbedrag <=@v_Max_Bodbedrag
BEGIN
 print 'inside'; 
 PRINT 'Bod moet hoger zijn dan gegeven bod';
 rollback transaction;
END;
ELSE
BEGIN
insert into bod 
select * from inserted;
PRINT 'Row Inserted';
END;
go

disable trigger trg_bod_validate_Bodbedrag on bod
go

