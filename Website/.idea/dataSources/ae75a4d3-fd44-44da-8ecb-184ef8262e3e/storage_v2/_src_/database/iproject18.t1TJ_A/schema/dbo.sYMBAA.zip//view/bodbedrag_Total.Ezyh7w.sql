CREATE VIEW [bodbedrag_Total] AS select SUM(convert(float, bodbedrag))as bodb from bod b inner join voorwerp on voorwerpnummer = voorwerp where veilinggesloten = 'wel' group by voorwerp
go

