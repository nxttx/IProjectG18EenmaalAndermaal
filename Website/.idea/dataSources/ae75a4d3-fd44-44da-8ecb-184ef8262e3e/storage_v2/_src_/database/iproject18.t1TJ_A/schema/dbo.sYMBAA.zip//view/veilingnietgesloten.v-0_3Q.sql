create view [veilingnietgesloten] as
select * from voorwerp where veilinggesloten = 'niet'
go

