

-- Beperking B2

CREATE TRIGGER trg_verkoper_validate_credit_card 
ON verkoper 
FOR INSERT, UPDATE
AS
	DECLARE @v_gebruiker char(25);
	DECLARE @v_Bank char(20);
	DECLARE @v_Bankrekening char(18);
	DECLARE @v_ControleOptie char(10);
	DECLARE @v_Creditcard numeric(16);
	select @v_Gebruiker=i.Gebruiker,@v_Bank=i.Bank,	@v_Bankrekening=i.Bankrekening,	
	@v_ControleOptie=i.ControleOptie,@v_Creditcard=i.Creditcard 	from Inserted i;

	IF(@v_ControleOptie = 'CreditCard' AND @v_Creditcard IS NULL)
		BEGIN
			RAISERROR ('Creditcard kan niet leeg zijn als er een creditcard aanwezig is', 16, 1)
			ROLLBACK TRANSACTION
		END
	ELSE
		PRINT 'Row Inserted';
go

