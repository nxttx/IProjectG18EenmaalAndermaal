
CREATE TRIGGER trg_bod_validare_obj_owner 
ON bod 
FOR INSERT, UPDATE
AS
	DECLARE @v_Voorwerp numeric(25);
	DECLARE @v_Bodbedrag char(6);
	DECLARE @v_Gebruiker char(25);
	DECLARE @v_BodDag DATE;
	DECLARE @v_BodTijdstip char(10);
	DECLARE @v_Verkoper char(25);

	select @v_Voorwerp=i.Voorwerp, @v_Bodbedrag=i.Bodbedrag,
	@v_Gebruiker=i.Gebruiker, @v_BodDag=i.BodDag, @v_BodTijdstip=i.BodTijdstip 
	from Inserted i;

	SELECT @v_Verkoper = Verkoper FROM voorwerp WHERE voorwerpnummer = @v_Voorwerp;

	IF @v_Gebruiker = @v_Verkoper
	BEGIN
			RAISERROR ('Een gebruiker kan niet bieden op zijn of haar eigen item', 16, 1)
			ROLLBACK TRANSACTION
	END;
	ELSE
		PRINT 'Row Inserted';
go

disable trigger trg_bod_validare_obj_owner on bod
go

