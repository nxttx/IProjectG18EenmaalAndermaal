-- Beperking B5
CREATE TRIGGER trg_bod_validate_Bodbedrag ON bod FOR INSERT, UPDATE
AS
	DECLARE @v_Voorwerp numeric(10);
	DECLARE @v_Bodbedrag char(5);
	DECLARE @v_Max_Bodbedrag char(5);

	select @v_Voorwerp=i.Voorwerp, @v_Bodbedrag=i.Bodbedrag 	from Inserted i;
	SELECT @v_Max_Bodbedrag = max(CAST(Bodbedrag AS INT)) FROM bod WHERE Voorwerp = @v_Voorwerp;

	IF @v_Max_Bodbedrag <= @v_Bodbedrag
	BEGIN
			RAISERROR ('Bod moet hoger zijn dan gegeven bod.', 16, 1)
			ROLLBACK TRANSACTION
	END;
	ELSE
		PRINT 'Row Inserted';



go

