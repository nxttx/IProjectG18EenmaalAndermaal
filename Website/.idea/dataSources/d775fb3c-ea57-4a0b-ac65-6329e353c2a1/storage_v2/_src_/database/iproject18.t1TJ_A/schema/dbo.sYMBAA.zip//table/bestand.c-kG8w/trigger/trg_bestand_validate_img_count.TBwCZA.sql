--Beperking B4
CREATE TRIGGER trg_bestand_validate_img_count ON bestand FOR INSERT, UPDATE
AS
	DECLARE @v_Filenaam char(13);
	DECLARE @v_voorwerpnummer numeric(10);
	DECLARE @v_voorwerp_Count int;  
	select @v_Filenaam=i.Filenaam,@v_voorwerpnummer=i.voorwerpnummer from Inserted i;
	SELECT @v_voorwerp_Count = COUNT(*) FROM bestand WHERE voorwerpnummer = @v_voorwerpnummer;
	IF @v_voorwerp_Count > 4
	BEGIN
			RAISERROR ('Kan niet meer dan 4 images per object toevoegen', 16, 1)
			ROLLBACK TRANSACTION
	END;
	ELSE
		PRINT 'Row Inserted';
go

